package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.4-1";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2022-07-01 09:21"
];

1;

